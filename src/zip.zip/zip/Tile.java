public class Tile {
    private int id;
    private int passable;

    public Tile(int id) {
        this.id = id;
    }
}
